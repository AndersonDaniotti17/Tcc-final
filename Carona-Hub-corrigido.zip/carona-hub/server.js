import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { initialize, transaction, id, hash, verify, validCPF } from './store.js';
import { validMpSignature, settlePayment, platformFee, encryptToken, decryptToken, validEncryptionKey } from './pagamentos.js';

const port = Number(process.env.PORT || 3000);
const publicDir = new URL('./public/', import.meta.url);
const templates = JSON.parse(await readFile(new URL('html/manifest.json', publicDir), 'utf8'));
// Marketplace (split): cada motorista conecta a própria conta e a plataforma retém a comissão.
// Sem CLIENT_ID/SECRET, usa o modo de conta única (todo o valor na conta do ACCESS_TOKEN).
const clientId = process.env.MERCADO_PAGO_CLIENT_ID || '';
const clientSecret = process.env.MERCADO_PAGO_CLIENT_SECRET || '';
const marketplace = Boolean(clientId && clientSecret);
const mpApi = (process.env.MERCADO_PAGO_API_URL || 'https://api.mercadopago.com').replace(/\/+$/, '');
const mpAuthHost = (process.env.MERCADO_PAGO_AUTH_URL || 'https://auth.mercadopago.com.br').replace(/\/+$/, '');
const feePercent = Number(process.env.PLATFORM_FEE_PERCENT ?? 15);
const encryptionKey = process.env.TOKEN_ENCRYPTION_KEY || '';
const paymentProvider = marketplace || process.env.MERCADO_PAGO_ACCESS_TOKEN ? 'mercadopago' : 'demo';
const mercadopago = paymentProvider === 'mercadopago' ? await import('mercadopago') : null;
const mpEnabled = paymentProvider === 'mercadopago' && Boolean(mercadopago);
const mpClient = process.env.MERCADO_PAGO_ACCESS_TOKEN && mercadopago
  ? new mercadopago.MercadoPagoConfig({ accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN })
  : null;

if (marketplace) {
  if (!Number.isFinite(feePercent) || feePercent < 0 || feePercent > 50) {
    throw new Error('PLATFORM_FEE_PERCENT deve ser um número entre 0 e 50.');
  }

  if (!validEncryptionKey(encryptionKey)) {
    throw new Error('Defina TOKEN_ENCRYPTION_KEY com 64 caracteres hexadecimais. Gere com: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"');
  }
}
const appUrl = (process.env.APP_URL || `http://localhost:${port}`).replace(/\/+$/, '');
const webhookSecret = process.env.MERCADO_PAGO_WEBHOOK_SECRET || '';
const isHttps = appUrl.startsWith('https://');

if (paymentProvider === 'mercadopago') {
  if (!webhookSecret) {
    console.warn('[Mercado Pago] MERCADO_PAGO_WEBHOOK_SECRET não definido: os avisos de pagamento serão recusados e nenhuma reserva será confirmada.');
  }

  if (!isHttps) {
    console.warn('[Mercado Pago] APP_URL não é https: o Mercado Pago não conseguirá avisar o webhook. Use um túnel (ngrok/cloudflared) em testes.');
  }
}

const refundMp = (client, mpPaymentId) =>
  new mercadopago.PaymentRefund(client).create({ payment_id: String(mpPaymentId), body: {} });

const chatMessages = (db, reservationId) =>
  (db.messages || []).filter((m) => m.reservationId === reservationId).sort((a, b) => a.date.localeCompare(b.date));

const canSeeChat = (user, reservation, trip) =>
  Boolean(user) && (user.role === 'admin' || user.id === reservation.userId || user.id === trip.driverId);

async function oauthToken(params) {
  const response = await fetch(`${mpApi}/oauth/token`, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, ...params }),
    signal: AbortSignal.timeout(10000)
  });
  const data = await response.json().catch(() => ({}));

  // Nunca inclua o corpo da resposta na mensagem: ele pode conter tokens.
  if (!response.ok || !data.access_token || !data.refresh_token) {
    throw new Error('OAuth do Mercado Pago falhou (HTTP ' + response.status + ').');
  }

  return data;
}

function saveSeller(driver, data) {
  driver.mpUserId = String(data.user_id);
  driver.mpAccessToken = encryptToken(data.access_token, encryptionKey);
  driver.mpRefreshToken = encryptToken(data.refresh_token, encryptionKey);
  driver.mpExpiresAt = new Date(Date.now() + Number(data.expires_in || 15552000) * 1000).toISOString();
}

const sellerConnected = (u) => Boolean(u?.mpAccessToken && new Date(u.mpExpiresAt) > new Date());

// Cliente do Mercado Pago que deve receber o pagamento (marketplace: o do motorista) e a comissão.
function sellerClientFor(driver) {
  if (!marketplace) {
    return { client: mpClient, fee: 0 };
  }

  if (!driver?.mpAccessToken) {
    fail('Este motorista ainda não conectou o Mercado Pago e não pode receber pagamentos.');
  }

  if (!sellerConnected(driver)) {
    fail('A conexão do motorista com o Mercado Pago expirou. Ele precisa reconectar.');
  }

  return {
    client: new mercadopago.MercadoPagoConfig({ accessToken: decryptToken(driver.mpAccessToken, encryptionKey) }),
    fee: feePercent
  };
}

// Renova os tokens dos motoristas (validade de 6 meses) em transação própria, fora das requisições:
// o refresh_token novo precisa ser gravado mesmo que outra operação falhe.
async function refreshSellers() {
  await transaction(async (db) => {
    for (const driver of db.users) {
      if (!driver.mpRefreshToken || new Date(driver.mpExpiresAt).getTime() - Date.now() > 30 * 864e5) {
        continue;
      }

      try {
        saveSeller(driver, await oauthToken({
          grant_type: 'refresh_token',
          refresh_token: decryptToken(driver.mpRefreshToken, encryptionKey)
        }));
      } catch (e) {
        console.error('[Mercado Pago] Renovação falhou para o motorista', driver.id, e.message);
      }
    }
  });
}

const publicAssets = [
  'index.html',
  'style.css',
  'favicon.svg',
  'images/pix-qr.svg',
  'js/interacoes.js',
  'js/html.js',
  'html/manifest.json',
  ...templates.map((name) => 'html/' + name + '.html')
];

const fail = (message, status = 400) => {
  throw Object.assign(new Error(message), { status });
};

const text = (v, max = 200) => String(v ?? '').trim().slice(0, max);

const required = (v, label) => {
  if (!text(v)) {
    fail('Preencha ' + label + '.');
  }

  return text(v);
};

const emailOf = (v) => {
  const e = text(v).toLowerCase();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
    fail('Informe um e-mail válido.');
  }

  return e;
};

const passwordOf = (v) => {
  if (typeof v !== 'string' || v.length < 8 || v.length > 128) {
    fail('A senha deve ter de 8 a 128 caracteres.');
  }

  return v;
};

const safeUser = (u) => {
  const { password, mpAccessToken, mpRefreshToken, mpExpiresAt, mpUserId, ...safe } = u;
  safe.mpConnected = sellerConnected(u);
  return safe;
};

const notify = (db, userId, message) =>
  db.notifications.push({
    id: id(),
    userId,
    message,
    date: new Date().toISOString(),
    read: false
  });

const free = (db, t) =>
  t.capacity -
  db.reservations
    .filter((r) => r.tripId === t.id && r.status === 'confirmada')
    .reduce((s, r) => s + r.quantity, 0);

const tripView = (db, t) => {
  const d = db.users.find((u) => u.id === t.driverId);
  const reviews = db.reviews.filter(
    (r) => db.trips.find((v) => v.id === r.tripId)?.driverId === d?.id
  );

  return {
    ...t,
    available: free(db, t),
    event: db.events.find((e) => e.id === t.eventId),
    driver: {
      name: d?.name,
      vehicle: d?.vehicle,
      color: d?.color,
      rating: reviews.length
        ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
        : null
    },
    reviews: reviews.map((r) => ({ rating: r.rating, comment: r.comment }))
  };
};

function validateTrip(db, b, allowPast = false) {
  const manualEvent = Boolean(b.eventName && b.eventLocation);
  let event = b.eventId ? db.events.find((e) => e.id === b.eventId) : null;

  if (!event && manualEvent) {
    event = {
      id: id(),
      name: required(b.eventName, 'o nome do evento'),
      category: required(b.eventCategory, 'a categoria do evento'),
      location: required(b.eventLocation, 'o local do evento'),
      date: new Date(b.date || Date.now()).toISOString(),
      description: text(b.eventDescription, 1000),
      approval: 'pendente',
      createdBy: b.createdBy || null
    };
    db.events.push(event);
  }

  if (!event) {
    fail('Cadastre ou selecione um evento.');
  }

  if (event.approval === 'rejeitada') {
    fail('Este evento foi rejeitado. Crie um novo evento para a viagem.');
  }

  if (!allowPast && event.approval !== 'aprovada' && !manualEvent) {
    fail('Selecione um evento aprovado.');
  }

  const date = new Date(b.date);

  if (!Number.isFinite(+date) || (!allowPast && date <= new Date()) || date > new Date(event.date)) {
    fail('A saída deve ser futura e anterior ao evento.');
  }

  const capacity = Number(b.capacity);
  const price = Number(b.price);

  if (!Number.isInteger(capacity) || capacity < 1 || capacity > 8) {
    fail('Informe de 1 a 8 vagas.');
  }

  if (!Number.isFinite(price) || price < 0 || price > 9999) {
    fail('Valor inválido.');
  }

  return {
    eventId: event.id,
    origin: required(b.origin, 'a origem'),
    destination: required(String(b.destination || b.eventLocation || ''), 'o destino ou local do evento'),
    date: date.toISOString(),
    capacity,
    price: Math.round(price * 100) / 100,
    notes: text(b.notes, 1000)
  };
}

function cancelTrip(db, t) {
  if (t.status !== 'agendada' || new Date(t.date) <= new Date()) {
    fail('A viagem já foi iniciada ou encerrada.');
  }

  t.status = 'cancelada';

  for (const r of db.reservations.filter((r) => r.tripId === t.id && r.status === 'confirmada')) {
    r.status = 'cancelada';
    notify(db, r.userId, 'A viagem para ' + t.destination + ' foi cancelada.');
  }
}

const attempts = new Map();

await initialize();

http
  .createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');

      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Referrer-Policy', 'same-origin');
      res.setHeader(
        'Content-Security-Policy',
        "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
      );

      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET') {
          fail('Método não permitido.', 405);
        }

        const path = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);

        if (!publicAssets.includes(path)) {
          fail('Página não encontrada.', 404);
        }

        const content = await readFile(new URL(path, publicDir));
        const mime = {
          html: 'text/html; charset=utf-8',
          js: 'text/javascript; charset=utf-8',
          css: 'text/css; charset=utf-8',
          svg: 'image/svg+xml',
          json: 'application/json; charset=utf-8'
        }[path.split('.').pop()];

        res.setHeader('Content-Type', mime);
        res.end(content);
        return;
      }

      res.setHeader('Cache-Control', 'no-store');

      if (
        req.method !== 'GET' &&
        req.headers.origin &&
        req.headers.origin !== `http://${req.headers.host}` &&
        req.headers.origin !== `https://${req.headers.host}`
      ) {
        fail('Origem não permitida.', 403);
      }

      let raw = '';

      for await (const chunk of req) {
        raw += chunk;

        if (raw.length > 30000) {
          fail('Dados muito grandes.', 413);
        }
      }

      let b = {};

      try {
        b = raw ? JSON.parse(raw) : {};
      } catch {
        fail('JSON inválido.');
      }

      const route = url.pathname.replace('/api/', '');
      const token = (req.headers.cookie || '')
        .split(';')
        .map((s) => s.trim())
        .find((s) => s.startsWith('session='))
        ?.slice(8);

      const result = await transaction(async (db) => {
        db.payments ??= [];
        db.mpStates ??= [];

        for (const e of db.events) {
          e.approval ??= 'aprovada';
        }

        for (const t of db.trips) {
          t.approval ??= 'aprovada';
          t.deleted = Boolean(t.deleted);
        }

        db.sessions = db.sessions.filter((s) => s.expires > Date.now());
        db.resets = db.resets.filter((s) => s.expires > Date.now());

        const user = db.users.find(
          (u) => u.id === db.sessions.find((s) => s.token === token)?.userId && u.active
        );

        const auth = (...roles) => {
          if (!user) {
            fail('Entre na sua conta para continuar.', 401);
          }

          if (roles.length && !roles.includes(user.role)) {
            fail('Seu perfil não tem permissão para esta ação.', 403);
          }
        };

        const audit = (action) =>
          db.logs.push({
            id: id(),
            userId: user.id,
            action,
            date: new Date().toISOString()
          });

        if (route === 'state' && req.method === 'GET') {
          return {
            user: user ? safeUser(user) : null,
            events: db.events.filter((e) => e.approval === 'aprovada'),
            myEvents: user ? db.events.filter((e) => e.createdBy === user.id) : [],
            trips: db.trips
              .filter(
                (t) =>
                  !t.deleted &&
                  t.approval === 'aprovada' &&
                  db.events.find((e) => e.id === t.eventId)?.approval === 'aprovada' &&
                  t.status === 'agendada' &&
                  new Date(t.date) > new Date() &&
                  db.users.find((u) => u.id === t.driverId)?.active &&
                  (!marketplace || sellerConnected(db.users.find((u) => u.id === t.driverId)))
              )
              .map((t) => tripView(db, t)),
            myTrips: user
              ? db.trips
                  .filter((t) => t.driverId === user.id && !t.deleted)
                  .map((t) => ({
                    ...tripView(db, t),
                    passengers: db.reservations
                      .filter((r) => r.tripId === t.id && r.status === 'confirmada')
                      .map((r) => ({
                        name: db.users.find((u) => u.id === r.userId)?.name,
                        quantity: r.quantity
                      }))
                  }))
              : [],
            reservations: user
              ? db.reservations
                  .filter((r) => r.userId === user.id)
                  .map((r) => ({
                    ...r,
                    messages: chatMessages(db, r.id),
                    trip: tripView(db, db.trips.find((t) => t.id === r.tripId)),
                    reviewed: db.reviews.some((v) => v.reservationId === r.id)
                  }))
              : [],
            payments: user
              ? db.payments
                  .filter((p) => p.userId === user.id)
                  .map(({ id, tripId, amount, method, status, createdAt, updatedAt }) => ({
                    id, tripId, amount, method, status, createdAt, updatedAt
                  }))
              : [],
            notifications: user ? db.notifications.filter((n) => n.userId === user.id).reverse() : [],
            payment: {
              provider: paymentProvider,
              marketplace,
              feePercent: marketplace ? feePercent : 0,
              enabled: true,
              currency: 'BRL',
              methods: ['pix', 'credit_card']
            },
            mode: process.env.STORAGE === 'mysql' ? 'mysql' : 'demo'
          };
        }

        // Conversas visíveis: passageiro (as suas), motorista (das suas viagens), admin (todas).
        if (route === 'chats' && req.method === 'GET') {
          auth('passageiro', 'motorista', 'admin');

          return {
            chats: db.reservations
              .map((r) => ({ r, trip: db.trips.find((t) => t.id === r.tripId) }))
              .filter(({ r, trip }) => trip && canSeeChat(user, r, trip))
              .map(({ r, trip }) => {
                const messages = chatMessages(db, r.id);
                return {
                  reservationId: r.id,
                  status: r.status,
                  open: r.status === 'confirmada',
                  destination: trip.destination,
                  origin: trip.origin,
                  tripDate: trip.date,
                  passenger: db.users.find((u) => u.id === r.userId)?.name || 'Passageiro',
                  driver: db.users.find((u) => u.id === trip.driverId)?.name || 'Motorista',
                  messages,
                  last: messages.at(-1)?.date || r.date
                };
              })
              .sort((a, b) => String(b.last).localeCompare(String(a.last)))
          };
        }

        if (route === 'mp/connect') {
          auth('motorista');

          if (!marketplace) {
            fail('A conexão com o Mercado Pago não está ativa.', 404);
          }

          db.mpStates = db.mpStates.filter((x) => x.expires > Date.now());

          const state = randomBytes(24).toString('hex');
          db.mpStates.push({ state, userId: user.id, expires: Date.now() + 10 * 60 * 1000 });

          const query = new URLSearchParams({
            client_id: clientId,
            response_type: 'code',
            platform_id: 'mp',
            state,
            redirect_uri: `${appUrl}/api/mp/callback`
          });

          return { url: `${mpAuthHost}/authorization?${query}` };
        }

        if (route === 'mp/callback' && req.method === 'GET') {
          if (!marketplace) {
            fail('A conexão com o Mercado Pago não está ativa.', 404);
          }

          const back = (flag) => ({ __redirect: `${appUrl}/?mp=${flag}` });
          const code = text(url.searchParams.get('code'), 300);
          const pending = db.mpStates.find((x) => x.state === text(url.searchParams.get('state'), 100));

          db.mpStates = db.mpStates.filter((x) => x.expires > Date.now() && x !== pending);

          // "state" liga o retorno ao motorista que iniciou a conexão e só vale uma vez.
          const driver = pending && pending.expires > Date.now()
            ? db.users.find((u) => u.id === pending.userId && u.role === 'motorista' && u.active)
            : null;

          if (!code || !driver) {
            return back('erro');
          }

          try {
            saveSeller(driver, await oauthToken({
              grant_type: 'authorization_code',
              code,
              redirect_uri: `${appUrl}/api/mp/callback`
            }));
          } catch (e) {
            console.error('[Mercado Pago]', e.message);
            return back('erro');
          }

          notify(db, driver.id, 'Conta Mercado Pago conectada. Suas viagens já podem receber reservas.');
          return back('conectado');
        }

        if (route === 'payment/webhook') {
          if (req.method !== 'POST') {
            fail('Método não permitido.', 405);
          }

          if (!mpEnabled) {
            fail('Pagamentos não configurados.', 404);
          }

          // O id assinado vem da query string (?data.id=...), como na documentação do Mercado Pago.
          const dataId = text(url.searchParams.get('data.id'), 64);

          if (!validMpSignature({ secret: webhookSecret, headers: req.headers, dataId })) {
            fail('Assinatura inválida.', 401);
          }

          const type = url.searchParams.get('type') || b.type || b.topic;

          if (type !== 'payment' || !/^\d+$/.test(dataId)) {
            return { received: true };
          }

          // O pagamento pertence à conta do motorista: a consulta usa o token dele (identificado pelo nosso registro).
          const record = db.payments.find((p) => p.id === text(url.searchParams.get('pid'), 40));

          if (marketplace && !record) {
            return { received: true };
          }

          const { client } = sellerClientFor(db.users.find((u) => u.id === record?.driverId));
          let mp;

          try {
            // Nunca confie no corpo do aviso: consulte o pagamento direto na API.
            mp = await new mercadopago.Payment(client).get({ id: dataId });
          } catch (e) {
            if (e?.status === 404) {
              return { received: true };
            }

            console.error('[Mercado Pago] Falha ao consultar pagamento', dataId, e?.message || e);
            fail('Falha ao consultar o Mercado Pago.', 502);
          }

          await settlePayment({ db, mp, refund: (mpId) => refundMp(client, mpId), notify, free, newId: id });
          return { received: true };
        }

        // Retorno do checkout (back_url traz ?payment_id=...). Necessário em localhost/http,
        // onde o Mercado Pago não consegue chamar o webhook. O status vem da API do MP, nunca do navegador.
        if (route === 'payment/check') {
          auth('passageiro');

          if (!mpEnabled) {
            fail('Pagamentos não configurados.', 404);
          }

          const mpId = text(String(b.paymentId || ''), 32);
          const record = db.payments.find((p) => p.id === text(String(b.reference || ''), 40) && p.userId === user.id);

          if (!/^\d+$/.test(mpId) || !record) {
            fail('Pagamento não encontrado.', 404);
          }

          const { client } = sellerClientFor(db.users.find((u) => u.id === record.driverId));
          let mp;

          try {
            mp = await new mercadopago.Payment(client).get({ id: mpId });
          } catch (e) {
            console.error('[Mercado Pago] Falha ao consultar pagamento', mpId, e?.message || e);
            fail('Não foi possível consultar o pagamento agora.', 502);
          }

          if (String(mp.external_reference) !== record.id) {
            fail('Pagamento não corresponde a esta reserva.', 403);
          }

          const result = await settlePayment({ db, mp, refund: (id_) => refundMp(client, id_), notify, free, newId: id });
          return { result, status: record.status };
        }

        if (route === 'payment/session') {
          auth('passageiro');

          const trip = db.trips.find((t) => t.id === b.tripId);

          if (!trip || trip.deleted || trip.approval !== 'aprovada' || trip.status !== 'agendada') {
            fail('Viagem indisponível.', 400);
          }

          const quantity = Number(b.quantity || 1);
          const paymentMethod = String(b.paymentMethod || 'pix');

          if (!['pix', 'credit_card'].includes(paymentMethod)) {
            fail('Forma de pagamento inválida. Escolha Pix ou cartão de crédito.');
          }

          if (!Number.isInteger(quantity) || quantity < 1 || quantity > free(db, trip)) {
            fail('Quantidade de vagas indisponível.');
          }

          const amount = Number((trip.price * quantity).toFixed(2));

          if (mpEnabled) {
            if (
              db.reservations.some(
                (r) => r.tripId === trip.id && r.userId === user.id && r.status === 'confirmada'
              )
            ) {
              fail('Você já tem uma reserva nesta viagem.');
            }

            // Marketplace: o pagamento vai para a conta do motorista e a comissão fica com a plataforma.
            const { client, fee } = sellerClientFor(db.users.find((u) => u.id === trip.driverId));
            const now = new Date().toISOString();
            const payment = {
              id: id(),
              tripId: trip.id,
              userId: user.id,
              driverId: trip.driverId,
              quantity,
              amount,
              fee: platformFee(amount, fee),
              method: paymentMethod,
              status: 'pendente',
              preferenceId: null,
              mpPaymentId: null,
              reservationId: null,
              createdAt: now,
              updatedAt: now
            };

            // Pix é "bank_transfer" no Mercado Pago. Mostra só o que o passageiro escolheu.
            const blocked = {
              credit_card: ['ticket', 'bank_transfer', 'debit_card'],
              debit_card: ['ticket', 'bank_transfer', 'credit_card'],
              pix: ['ticket', 'credit_card', 'debit_card']
            }[paymentMethod];

            const body = {
              items: [{
                id: trip.id,
                title: 'Reserva de carona — ' + trip.destination,
                quantity: 1,
                unit_price: amount,
                currency_id: 'BRL'
              }],
              payer: { name: user.name, email: user.email },
              payment_methods: { excluded_payment_types: blocked.map((type) => ({ id: type })) },
              external_reference: payment.id,
              ...(payment.fee > 0 ? { marketplace_fee: payment.fee } : {}),
              statement_descriptor: 'CARONAHUB',
              expires: true,
              date_of_expiration: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
              back_urls: {
                success: `${appUrl}/?pagamento=sucesso`,
                pending: `${appUrl}/?pagamento=pendente`,
                failure: `${appUrl}/?pagamento=falha`
              }
            };

            // O Mercado Pago só aceita retorno automático e aviso (webhook) em endereço público https.
            if (isHttps) {
              body.auto_return = 'approved';
              body.notification_url = `${appUrl}/api/payment/webhook?pid=${payment.id}`;
            }

            const result = await new mercadopago.Preference(client).create({ body });
            const tokenForEnvironment = marketplace
              ? decryptToken(db.users.find((u) => u.id === trip.driverId)?.mpAccessToken, encryptionKey)
              : process.env.MERCADO_PAGO_ACCESS_TOKEN || '';
            const isTestCredential = /^(TEST-|TEST_)/i.test(tokenForEnvironment);
            const checkoutUrl = isTestCredential
              ? (result.sandbox_init_point || result.init_point || null)
              : (result.init_point || result.sandbox_init_point || null);

            if (!checkoutUrl) {
              fail('Não foi possível abrir o pagamento agora. Tente novamente.', 502);
            }

            payment.preferenceId = result.id;
            db.payments.push(payment);

            return {
              provider: 'mercadopago',
              paymentMethod,
              paymentId: payment.id,
              sessionId: result.id,
              checkoutUrl,
              amount,
              currency: 'BRL'
            };
          }

          const payment = {
            id: id(),
            tripId: trip.id,
            userId: user.id,
            driverId: trip.driverId,
            quantity,
            amount,
            fee: 0,
            method: paymentMethod,
            status: 'pendente',
            preferenceId: null,
            mpPaymentId: null,
            reservationId: null,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          db.payments.push(payment);

          return {
            provider: 'demo',
            paymentMethod,
            paymentId: payment.id,
            sessionId: 'demo_' + id(),
            checkoutUrl: null,
            amount,
            currency: 'BRL'
          };
        }

        if (req.method !== 'POST') {
          fail('Rota não encontrada.', 404);
        }

        if (['login', 'register', 'recover'].includes(route)) {
          const key = req.socket.remoteAddress;
          const a = attempts.get(key) || { count: 0, expires: Date.now() + 60000 };

          if (a.expires < Date.now()) {
            a.count = 0;
            a.expires = Date.now() + 60000;
          }

          a.count += 1;
          attempts.set(key, a);

          if (a.count > 25) {
            fail('Muitas tentativas. Aguarde um minuto.', 429);
          }
        }

        if (route === 'register') {
          const name = required(b.name, 'o nome');
          const email = emailOf(b.email);
          const cpf = text(b.cpf).replace(/\D/g, '');

          if (!validCPF(cpf)) {
            fail('CPF inválido.');
          }

          const phone = text(b.phone).replace(/\D/g, '');

          if (!/^\d{10,11}$/.test(phone)) {
            fail('Telefone inválido.');
          }

          if (db.users.some((u) => u.email === email || u.cpf === cpf)) {
            fail('E-mail ou CPF já cadastrado.');
          }

          if (!['passageiro', 'motorista'].includes(b.role)) {
            fail('Perfil inválido.');
          }

          const u = {
            id: id(),
            name,
            email,
            cpf,
            phone,
            password: hash(passwordOf(b.password)),
            role: b.role,
            active: true,
            createdAt: new Date().toISOString()
          };

          if (b.role === 'motorista') {
            u.cnh = required(b.cnh, 'a CNH');

            if (!/^\d{11}$/.test(u.cnh)) {
              fail('A CNH deve ter 11 dígitos.');
            }

            u.vehicle = required(b.vehicle, 'o modelo do veículo');
            u.plate = required(b.plate, 'a placa').toUpperCase();

            if (!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(u.plate)) {
              fail('Placa inválida. Use ABC1D23 ou ABC1234.');
            }

            u.color = required(b.color, 'a cor');
          }

          db.users.push(u);
          notify(db, u.id, 'Bem-vindo ao Carona Hub! Seu cadastro está pronto.');

          return { message: 'Conta criada. Entre com seu e-mail e senha.' };
        }

        if (route === 'login') {
          const u = db.users.find((u) => u.email === text(b.email).toLowerCase());

          if (!u || !verify(String(b.password || ''), u.password) || !u.active) {
            fail('E-mail ou senha inválidos, ou conta bloqueada.', 401);
          }

          const t = randomBytes(32).toString('hex');
          db.sessions.push({
            token: t,
            userId: u.id,
            expires: Date.now() + 86400000
          });

          res.setHeader(
            'Set-Cookie',
            `session=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`
          );

          return { message: 'Você entrou na sua conta.' };
        }

        if (route === 'logout') {
          db.sessions = db.sessions.filter((s) => s.token !== token);
          res.setHeader('Set-Cookie', 'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
          return {};
        }

        if (route === 'recover') {
          const email = emailOf(b.email);
          const u = db.users.find((u) => u.email === email);

          if (u) {
            const t = randomBytes(32).toString('hex');
            db.resets = db.resets.filter((r) => r.userId !== u.id);
            db.resets.push({ token: t, userId: u.id, expires: Date.now() + 900000 });

            const link = (process.env.APP_URL || `http://localhost:${port}`) + '/?reset=' + t;

            if (process.env.SMTP_HOST) {
              const mail = await import('nodemailer');

              await mail.default
                .createTransport({
                  host: process.env.SMTP_HOST,
                  port: Number(process.env.SMTP_PORT || 587),
                  secure: Number(process.env.SMTP_PORT) === 465,
                  auth: {
                    user: process.env.SMTP_USER,
                    pass: process.env.SMTP_PASSWORD
                  }
                })
                .sendMail({
                  from: process.env.SMTP_FROM,
                  to: email,
                  subject: 'Carona Hub — redefinir senha',
                  text: 'Link válido por 15 minutos: ' + link
                });
            } else {
              console.log('\n[Recuperação local — não enviado por e-mail] ' + link + '\n');
            }
          }

          return {
            message:
              'Se o e-mail estiver cadastrado, as instruções serão geradas. No modo local sem SMTP, consulte o terminal do servidor.'
          };
        }

        if (route === 'reset') {
          const r = db.resets.find((r) => r.token === b.token);

          if (!r) {
            fail('Link inválido ou expirado.');
          }

          db.users.find((u) => u.id === r.userId).password = hash(passwordOf(b.password));
          db.resets = db.resets.filter((x) => x.userId !== r.userId);
          db.sessions = db.sessions.filter((x) => x.userId !== r.userId);

          return { message: 'Senha atualizada. Entre novamente.' };
        }

        auth();

        if (route === 'profile') {
          const email = emailOf(b.email);

          if (db.users.some((u) => u.id !== user.id && u.email === email)) {
            fail('E-mail já utilizado.');
          }

          const phone = text(b.phone).replace(/\D/g, '');

          if (!/^\d{10,11}$/.test(phone)) {
            fail('Telefone inválido.');
          }

          user.name = required(b.name, 'o nome');
          user.email = email;
          user.phone = phone;

          if (b.password) {
            if (!verify(String(b.currentPassword || ''), user.password)) {
              fail('Senha atual incorreta.');
            }

            user.password = hash(passwordOf(b.password));
            db.sessions = db.sessions.filter((s) => s.userId !== user.id || s.token === token);
          }

          return { message: 'Perfil atualizado.' };
        }

        if (route === 'notifications/read') {
          db.notifications.filter((n) => n.userId === user.id).forEach((n) => {
            n.read = true;
          });

          return {};
        }

        if (route === 'trips/save') {
          auth('motorista', 'admin');

          let t = b.id ? db.trips.find((t) => t.id === b.id) : null;

          if (b.id && !t) {
            fail('Viagem não encontrada.', 404);
          }

          if (t && user.role !== 'admin' && t.driverId !== user.id) {
            fail('Acesso negado.', 403);
          }

          if (t?.deleted) {
            fail('Viagem excluída.', 404);
          }

          if (t && user.role !== 'admin' && (t.status !== 'agendada' || new Date(t.date) <= new Date())) {
            fail('Viagem iniciada ou encerrada.');
          }

          if (user.role === 'motorista' && !b.eventId && b.eventName) {
            b.createdBy = user.id;
          }

          const fields = validateTrip(db, b, user.role === 'admin' && Boolean(t));

          if (t) {
            const occupied = t.capacity - free(db, t);

            if (fields.capacity < occupied) {
              fail('Há mais vagas reservadas do que a nova capacidade.');
            }

            Object.assign(t, fields);

            if (user.role === 'motorista') {
              t.approval = 'pendente';
            }

            db.reservations
              .filter((r) => r.tripId === t.id && r.status === 'confirmada')
              .forEach((r) =>
                notify(db, r.userId, 'Os dados da sua viagem para ' + t.destination + ' foram atualizados.')
              );
          } else {
            if (user.role !== 'motorista') {
              fail('Use uma conta de motorista para oferecer carona.');
            }

            db.trips.push({
              id: id(),
              driverId: user.id,
              ...fields,
              status: 'agendada',
              approval: 'pendente',
              deleted: false
            });
          }

          if (user.role === 'motorista') {
            db.users
              .filter((u) => u.role === 'admin' && u.active)
              .forEach((u) => notify(db, u.id, 'Uma viagem aguarda aprovação.'));
          }

          audit('Viagem salva');

          return {
            message: user.role === 'motorista' ? 'Viagem enviada para aprovação.' : 'Viagem atualizada.'
          };
        }

        if (route === 'trips/status') {
          auth('motorista', 'admin');

          const t = db.trips.find((t) => t.id === b.id);

          if (!t || t.deleted) {
            fail('Viagem não encontrada.', 404);
          }

          if (user.role !== 'admin' && t.driverId !== user.id) {
            fail('Acesso negado.', 403);
          }

          if (b.status === 'cancelada') {
            cancelTrip(db, t);
          } else if (b.status === 'concluida' && t.status === 'agendada' && t.approval === 'aprovada') {
            if (new Date(t.date) > new Date()) {
              fail('Aguarde o horário da viagem para concluir.');
            }

            t.status = 'concluida';
            db.reservations
              .filter((r) => r.tripId === t.id && r.status === 'confirmada')
              .forEach((r) => notify(db, r.userId, 'Viagem concluída! Você já pode avaliar o motorista.'));
          } else {
            fail('Alteração inválida.');
          }

          audit('Status da viagem alterado');
          return { message: 'Viagem atualizada.' };
        }

        if (route === 'payment/confirm') {
          auth('passageiro');

          const trip = db.trips.find((t) => t.id === b.tripId);

          if (!trip || trip.deleted || trip.approval !== 'aprovada' || trip.status !== 'agendada') {
            fail('Viagem indisponível.', 400);
          }

          const quantity = Number(b.quantity || 1);
          const method = String(b.paymentMethod || 'pix');

          if (mpEnabled) {
            fail('A confirmação de pagamentos reais é feita exclusivamente pelo webhook do Mercado Pago.', 403);
          }

          if (!['pix', 'credit_card'].includes(method)) {
            fail('Forma de pagamento inválida. Escolha Pix ou cartão de crédito.', 400);
          }

          if (!Number.isInteger(quantity) || quantity < 1 || quantity > free(db, trip)) {
            fail('Quantidade de vagas indisponível.', 400);
          }

          const payment = db.payments.find(
            (p) =>
              p.userId === user.id &&
              p.tripId === trip.id &&
              p.quantity === quantity &&
              p.amount === Number((trip.price * quantity).toFixed(2)) &&
              p.method === method &&
              p.status === 'pendente'
          );

          if (!payment) {
            fail('O pagamento do Pix ainda não foi gerado para esta viagem.', 400);
          }

          payment.status = 'aprovado';
          payment.updatedAt = new Date().toISOString();

          return {
            provider: 'demo',
            paymentMethod: method,
            paymentId: payment.id,
            amount: payment.amount,
            currency: 'BRL',
            message: 'Pagamento confirmado. Agora você pode reservar a viagem.'
          };
        }

        if (route === 'reserve') {
          auth('passageiro');

          const t = db.trips.find((t) => t.id === b.tripId);

          if (
            !t ||
            t.deleted ||
            t.approval !== 'aprovada' ||
            db.events.find((e) => e.id === t.eventId)?.approval !== 'aprovada' ||
            t.status !== 'agendada' ||
            new Date(t.date) <= new Date() ||
            !db.users.find((u) => u.id === t.driverId)?.active
          ) {
            fail('Viagem indisponível.');
          }

          const quantity = Number(b.quantity);

          if (!Number.isInteger(quantity) || quantity < 1 || quantity > free(db, t)) {
            fail('Quantidade de vagas indisponível.');
          }

          const paid = db.payments.some(
            (p) =>
              p.userId === user.id &&
              p.tripId === t.id &&
              p.quantity === quantity &&
              p.amount === Number((t.price * quantity).toFixed(2)) &&
              ['pix', 'credit_card'].includes(p.method) &&
              p.status === 'aprovado'
          );

          if (!paid) {
            fail('Para reservar é necessário concluir e confirmar o pagamento primeiro.', 400);
          }

          if (db.reservations.some((r) => r.tripId === t.id && r.userId === user.id && r.status === 'confirmada')) {
            fail('Você já tem uma reserva nesta viagem.');
          }

          const reservation = {
            id: id(),
            tripId: t.id,
            userId: user.id,
            quantity,
            status: 'confirmada',
            date: new Date().toISOString()
          };

          db.reservations.push(reservation);
          // Primeira mensagem do chat: o ponto de encontro informado pelo motorista.
          db.messages ??= [];
          db.messages.push({
            id: id(),
            reservationId: reservation.id,
            userId: t.driverId,
            role: 'motorista',
            text: t.notes || 'Ponto de encontro a confirmar com o motorista.',
            date: reservation.date
          });

          notify(db, user.id, 'Reserva confirmada para ' + t.destination + '.');
          notify(db, t.driverId, user.name + ' reservou ' + quantity + ' vaga(s).');

          return { message: 'Reserva confirmada! Veja os detalhes em Minhas reservas.' };
        }

        if (route === 'chat/send') {
          auth('passageiro', 'motorista', 'admin');

          const reservation = db.reservations.find((r) => r.id === b.reservationId);

          if (!reservation) {
            fail('Reserva não encontrada.', 404);
          }

          const trip = db.trips.find((t) => t.id === reservation.tripId);

          if (!trip) {
            fail('Viagem não encontrada.', 404);
          }

          if (reservation.status !== 'confirmada') {
            fail('O chat só fica liberado após a confirmação do pagamento.', 403);
          }

          if (!canSeeChat(user, reservation, trip)) {
            fail('Você não participa desta conversa.', 403);
          }

          const message = text(b.message, 500);

          if (!message) {
            fail('Escreva uma mensagem para continuar.');
          }

          db.messages ??= [];
          db.messages.push({
            id: id(),
            reservationId: reservation.id,
            userId: user.id,
            role: user.role,
            text: message,
            date: new Date().toISOString()
          });

          const peers = user.role === 'admin' ? [reservation.userId, trip.driverId] : [user.id === reservation.userId ? trip.driverId : reservation.userId];
          peers.filter((id) => id && id !== user.id).forEach((peerId) => notify(db, peerId, 'Nova mensagem sobre a viagem para ' + trip.destination + '.'));

          return { messages: chatMessages(db, reservation.id) };
        }

        if (route === 'reservations/cancel') {
          const r = db.reservations.find((r) => r.id === b.id);

          if (!r) {
            fail('Reserva não encontrada.', 404);
          }

          if (user.role !== 'admin' && r.userId !== user.id) {
            fail('Acesso negado.', 403);
          }

          const t = db.trips.find((t) => t.id === r.tripId);

          if (r.status !== 'confirmada' || t.status !== 'agendada' || new Date(t.date) <= new Date()) {
            fail('Não é possível cancelar esta reserva.');
          }

          const paid = db.payments.find((p) => p.reservationId === r.id && p.status === 'aprovado');

          // Reembolsa ANTES de cancelar: se o Mercado Pago falhar, nada é alterado e o usuário pode tentar de novo.
          if (paid && mpEnabled) {
            try {
              const { client } = sellerClientFor(db.users.find((u) => u.id === paid.driverId));
              await refundMp(client, paid.mpPaymentId);
            } catch (e) {
              console.error('[Mercado Pago] Falha no reembolso', paid.mpPaymentId, e?.message || e);
              fail('Não foi possível processar o reembolso agora. Tente novamente em alguns minutos.', 502);
            }

            paid.status = 'reembolsado';
            paid.updatedAt = new Date().toISOString();
          }

          r.status = 'cancelada';
          notify(db, t.driverId, 'Uma reserva foi cancelada. As vagas estão disponíveis novamente.');
          notify(db, r.userId, 'Sua reserva foi cancelada.');
          audit('Reserva cancelada');

          return {
            message: paid
              ? 'Reserva cancelada e vagas devolvidas. O reembolso foi solicitado ao Mercado Pago.'
              : 'Reserva cancelada e vagas devolvidas.'
          };
        }

        if (route === 'reviews') {
          const r = db.reservations.find(
            (r) => r.id === b.id && r.userId === user.id && r.status === 'confirmada'
          );

          if (!r || db.trips.find((t) => t.id === r.tripId)?.status !== 'concluida') {
            fail('Somente viagens concluídas podem ser avaliadas.');
          }

          if (db.reviews.some((v) => v.reservationId === r.id)) {
            fail('Esta viagem já foi avaliada.');
          }

          const rating = Number(b.rating);

          if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
            fail('Escolha de 1 a 5 estrelas.');
          }

          db.reviews.push({
            id: id(),
            reservationId: r.id,
            tripId: r.tripId,
            rating,
            comment: text(b.comment, 1000),
            date: new Date().toISOString()
          });

          return { message: 'Avaliação enviada. Obrigado!' };
        }

        if (route === 'events/save') {
          auth('motorista', 'admin');

          if (b.id) {
            fail('Novos eventos devem ser enviados sem identificador.');
          }

          const date = new Date(b.date);

          if (!Number.isFinite(+date) || date <= new Date()) {
            fail('Informe uma data futura.');
          }

          const event = {
            id: id(),
            name: required(b.name, 'o nome'),
            location: required(b.location, 'o local'),
            category: required(b.category, 'a categoria'),
            date: date.toISOString(),
            description: text(b.description, 1000),
            approval: 'pendente',
            createdBy: user.id
          };

          db.events.push(event);
          db.users
            .filter((u) => u.role === 'admin' && u.active)
            .forEach((u) => notify(db, u.id, 'Novo evento aguardando aprovação: ' + event.name));

          audit('Evento enviado para aprovação');
          return { message: 'Evento enviado para aprovação.' };
        }

        if (route.startsWith('admin/')) {
          auth('admin');

          if (route === 'admin/data') {
            return {
              users: db.users.map(safeUser),
              trips: db.trips.filter((t) => !t.deleted).map((t) => tripView(db, t)),
              events: db.events,
              reservations: db.reservations.map((r) => ({
                ...r,
                name: db.users.find((u) => u.id === r.userId)?.name,
                destination: db.trips.find((t) => t.id === r.tripId)?.destination
              })),
              reviews: db.reviews,
              logs: db.logs
            };
          }

          if (route === 'admin/moderate') {
            const collection = b.kind === 'trip' ? db.trips : b.kind === 'event' ? db.events : null;

            if (!collection) {
              fail('Tipo inválido.');
            }

            const record = collection.find((x) => x.id === b.id && !x.deleted);

            if (!record) {
              fail('Registro não encontrado.', 404);
            }

            if (record.approval !== 'pendente') {
              fail('Este registro já foi analisado.');
            }

            if (!['aprovada', 'rejeitada'].includes(b.approval)) {
              fail('Decisão inválida.');
            }

            if (b.approval === 'aprovada') {
              if (new Date(record.date) <= new Date()) {
                fail('Atualize a data antes de aprovar.');
              }

              if (b.kind === 'trip') {
                if (record.status !== 'agendada') {
                  fail('Somente viagens agendadas podem ser aprovadas.');
                }

                if (!db.users.find((u) => u.id === record.driverId)?.active) {
                  fail('Motorista bloqueado.');
                }

                if (db.events.find((e) => e.id === record.eventId)?.approval !== 'aprovada') {
                  fail('Aprove o evento antes da viagem.');
                }
              }
            }

            if (b.approval === 'rejeitada') {
              const reason = text(b.reason, 500);

              if (!reason) {
                fail('Informe o motivo da rejeição.');
              }

              record.rejectionReason = reason;
            } else {
              record.rejectionReason = null;
            }

            record.approval = b.approval;
            const owner = record.driverId || record.createdBy;

            if (owner) {
              const label = b.kind === 'trip' ? 'Sua viagem foi ' : 'Seu evento foi ';
              const reasonText = b.approval === 'rejeitada' ? ' rejeitada. Motivo: ' + text(b.reason, 500) : ' ' + b.approval + '.';
              notify(db, owner, label + reasonText);
            }

            audit('Aprovação ' + b.kind + ' ' + record.id + ': ' + b.approval);

            return {
              message: b.approval === 'aprovada' ? 'Registro aprovado e publicado.' : 'Registro rejeitado.'
            };
          }

          if (route === 'admin/trip/delete') {
            const t = db.trips.find((t) => t.id === b.id && !t.deleted);

            if (!t) {
              fail('Viagem não encontrada.', 404);
            }

            t.deleted = true;
            t.status = 'cancelada';

            for (const r of db.reservations.filter((r) => r.tripId === t.id && r.status === 'confirmada')) {
              r.status = 'cancelada';
              notify(db, r.userId, 'A administração excluiu sua viagem para ' + t.destination + '. A reserva foi cancelada.');
            }

            notify(db, t.driverId, 'A administração excluiu sua viagem para ' + t.destination + '.');
            audit('Viagem excluída: ' + t.id);

            return { message: 'Viagem excluída. O histórico das reservas foi preservado.' };
          }

          if (route === 'admin/user/save') {
            const u = db.users.find((u) => u.id === b.id);

            if (!u) {
              fail('Usuário não encontrado.', 404);
            }

            const email = emailOf(b.email);
            const phone = text(b.phone).replace(/\D/g, '');

            if (db.users.some((x) => x.id !== u.id && x.email === email)) {
              fail('E-mail já utilizado.');
            }

            if (!/^\d{10,11}$/.test(phone)) {
              fail('Telefone inválido.');
            }

            u.name = required(b.name, 'o nome');
            u.email = email;
            u.phone = phone;
            audit('Cadastro do usuário ' + u.id + ' atualizado');

            return { message: 'Cadastro atualizado.' };
          }

          if (route === 'admin/user') {
            const u = db.users.find((u) => u.id === b.id);

            if (!u || u.id === user.id) {
              fail('Não é possível alterar este usuário.');
            }

            u.active = !u.active;

            if (!u.active) {
              db.sessions = db.sessions.filter((s) => s.userId !== u.id);
            }

            audit('Status do usuário ' + u.id + ' alterado');
            return { message: 'Usuário atualizado.' };
          }

          if (route === 'admin/event') {
            const e = b.id ? db.events.find((e) => e.id === b.id) : null;

            if (b.id && !e) {
              fail('Evento não encontrado.');
            }

            if (b.remove) {
              if (db.trips.some((t) => t.eventId === e.id)) {
                fail('Este evento possui viagens vinculadas.');
              }

              db.events = db.events.filter((x) => x.id !== e.id);
            } else {
              const date = new Date(b.date);

              if (!Number.isFinite(+date) || date <= new Date()) {
                fail('Informe uma data futura.');
              }

              if (
                e &&
                db.trips.some(
                  (t) => t.eventId === e.id && t.status === 'agendada' && new Date(t.date) > date
                )
              ) {
                fail('O evento não pode ocorrer antes da saída das viagens vinculadas.');
              }

              const fields = {
                name: required(b.name, 'o nome'),
                location: required(b.location, 'o local'),
                category: required(b.category, 'a categoria'),
                date: date.toISOString(),
                description: text(b.description, 1000)
              };

              if (e) {
                Object.assign(e, fields);
              } else {
                db.events.push({
                  id: id(),
                  ...fields,
                  approval: 'pendente',
                  createdBy: user.id
                });
              }
            }

            audit('Evento atualizado');
            return { message: 'Evento atualizado.' };
          }
        }

        fail('Rota não encontrada.', 404);
      });

      if (result?.__redirect) {
        res.statusCode = 302;
        res.setHeader('Location', result.__redirect);
        res.end();
        return;
      }

      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.end(JSON.stringify(result));
    } catch (e) {
      res.statusCode = e.status || 500;
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.end(
        JSON.stringify({
          error: e.status ? e.message : 'Erro no servidor. Consulte o terminal.'
        })
      );

      if (!e.status) {
        console.error(e.message);
      }
    }
  })
  .listen(port, '127.0.0.1', () =>
    console.log(
      `Carona Hub: http://localhost:${port}\nArmazenamento: ${process.env.STORAGE === 'mysql' ? 'MySQL' : 'demonstração JSON local'}`
    )
  );

if (marketplace) {
  const renew = () =>
    refreshSellers().catch((e) => console.error('[Mercado Pago] Renovação de tokens falhou:', e.message));

  setTimeout(renew, 5000).unref();
  setInterval(renew, 12 * 60 * 60 * 1000).unref();
}
