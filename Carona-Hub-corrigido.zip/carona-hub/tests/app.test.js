import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { once } from 'node:events';
import { hash, verify, validCPF } from '../store.js';

async function seedTestData(dir) {
 const future=(days)=>new Date(Date.now()+days*86400000).toISOString();
 const users=[
  {id:'p1',name:'Marina Costa',role:'passageiro',email:'passageiro@caronahub.local'},
  {id:'d1',name:'Lucas Almeida',role:'motorista',email:'motorista@caronahub.local'},
  {id:'a1',name:'Administrador',role:'admin',email:'admin@caronahub.local'}
 ].map(u=>({...u,password:hash('Carona@123'),phone:'13999999999',cpf:'',active:true,vehicle:'Honda Civic',plate:'ABC1D23',color:'Prata',cnh:'12345678901',createdAt:new Date().toISOString()}));
 const events=[
  {id:'event1',name:'Evento de teste 1',category:'Música',location:'Santos',date:future(40),approval:'aprovada',createdBy:'d1'},
  {id:'event2',name:'Evento de teste 2',category:'Esporte',location:'São Paulo',date:future(70),approval:'aprovada',createdBy:'d1'}
 ];
 const trips=[
  {id:'trip1',driverId:'d1',eventId:'event1',origin:'Mongaguá',destination:'Santos',date:future(10),capacity:3,price:35,notes:'Ponto de encontro',status:'agendada',approval:'aprovada',deleted:false},
  {id:'trip2',driverId:'d1',eventId:'event2',origin:'Mongaguá',destination:'São Paulo',date:future(15),capacity:3,price:40,notes:'Ponto de encontro',status:'agendada',approval:'aprovada',deleted:false},
  {id:'trip3',driverId:'d1',eventId:'event1',origin:'Praia Grande',destination:'Santos',date:future(20),capacity:3,price:25,notes:'Ponto de encontro',status:'agendada',approval:'aprovada',deleted:false}
 ];
 await writeFile(dir+'/state.json',JSON.stringify({users,events,trips,reservations:[],payments:[],reviews:[],notifications:[],sessions:[],resets:[],logs:[],mpStates:[]},null,2));
}

test('CPF e hash de senha',()=>{assert.equal(validCPF('529.982.247-25'),true);assert.equal(validCPF('11111111111'),false);assert.equal(validCPF('52998224724'),false);const h=hash('Teste@123');assert.equal(verify('Teste@123',h),true);assert.equal(verify('errada',h),false);assert.notEqual(h,hash('Teste@123'));});

test('Sistema começa sem eventos e viagens fixos; o motorista cadastra o evento',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-seed-test-'));
 let child;let output='';const port=31390;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 const response=await fetch(`http://localhost:${port}/api/state`);
 const state=await response.json();
 assert.equal(state.trips.length,0);
 assert.equal(state.events.length,0);
 await stop();
});

test('Motorista informa o nome do evento em vez de selecionar um evento pré-definido',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-evento-manual-'));
 let child;let output='';const port=31395;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 async function request(route,body,cookie=''){const response=await fetch(`http://localhost:${port}/api/${route}`,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(cookie?{cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});return {status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]};}
 const d=(await request('login',{email:'motorista@caronahub.local',password:'Carona@123'})).cookie;
 const result=await request('trips/save',{eventName:'Evento escrito pelo motorista',eventCategory:'Cultura',eventLocation:'Praia Grande',origin:'Santos',destination:'Praia Grande',date:new Date(Date.now()+86400000*4).toISOString(),capacity:3,price:35,notes:'Ponto de encontro na praça central.'},d);
 assert.equal(result.status,200, result.data?.error || result.data?.message);
 const state=(await request('state',undefined,d)).data;
 const trip=state.myTrips.find(t=>t.event?.name==='Evento escrito pelo motorista');
 assert.ok(trip, 'Não criou a viagem para o evento digitado pelo motorista');
 assert.equal(trip.event.approval,'pendente');
 await stop();
});

test('API de pagamento aceita checkout em modo demo',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-pay-test-'));
 await seedTestData(dir);
 let child;let output='';const port=31388;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 const response=await fetch(`http://localhost:${port}/api/state`);
 const state=await response.json();
 assert.equal(state.payment.provider,'demo');
 assert.equal(typeof state.payment.enabled,'boolean');
 const login=(await fetch(`http://localhost:${port}/api/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'passageiro@caronahub.local',password:'Carona@123'})}));
 const cookie=login.headers.get('set-cookie')?.split(';')[0];
 const session=(await fetch(`http://localhost:${port}/api/payment/session`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1})}));
 assert.equal(session.status,200);
 const payload=await session.json();
 assert.equal(payload.provider,'demo');
 assert.ok(payload.amount>0);
 await stop();
});

test('Modo demo oferece Pix e cartão e exige confirmação simulada antes da reserva',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-pix-test-'));
 await seedTestData(dir);
 let child;let output='';const port=31389;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 const state=(await fetch(`http://localhost:${port}/api/state`)).json();
 assert.deepEqual((await state).payment.methods,['pix','credit_card']);
 const login=(await fetch(`http://localhost:${port}/api/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'passageiro@caronahub.local',password:'Carona@123'})}));
 const cookie=login.headers.get('set-cookie')?.split(';')[0];
 const cardSession=(await fetch(`http://localhost:${port}/api/payment/session`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1,paymentMethod:'credit_card'})}));
 assert.equal(cardSession.status,200);
 assert.equal((await cardSession.json()).paymentMethod,'credit_card');
 const session=(await fetch(`http://localhost:${port}/api/payment/session`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1,paymentMethod:'pix'})}));
 assert.equal(session.status,200);
 const payload=await session.json();
 assert.equal(payload.paymentMethod,'pix');
 assert.ok(payload.amount>0);
 const reserveBeforePayment=(await fetch(`http://localhost:${port}/api/reserve`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1})}));
 assert.equal(reserveBeforePayment.status,400, 'A reserva não deve confirmar sem pagamento aprovado.');
 const confirm=(await fetch(`http://localhost:${port}/api/payment/confirm`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1,paymentMethod:'pix'})}));
 assert.equal(confirm.status,200, 'O pagamento de demonstração precisa ser confirmado antes da reserva.');
 const reserveAfterPayment=(await fetch(`http://localhost:${port}/api/reserve`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({tripId:'trip1',quantity:1})}));
 assert.equal(reserveAfterPayment.status,200, 'A reserva precisa entrar após o pagamento confirmado.');
 const reservationState=(await fetch(`http://localhost:${port}/api/state`,{headers:{cookie}}));
 const reservationId=(await reservationState.json()).reservations.at(-1).id;
 const sendMessage=(await fetch(`http://localhost:${port}/api/chat/send`,{method:'POST',headers:{'Content-Type':'application/json',cookie},body:JSON.stringify({reservationId,message:'O ponto de encontro é na praça central.'})}));
 assert.equal(sendMessage.status,200, 'O chat da reserva deve aceitar mensagens do ponto de encontro.');
 const body=await sendMessage.json();
 assert.ok(Array.isArray(body.messages));
 assert.ok(body.messages.some((m)=>m.text.includes('praça central')));
 await stop();
});

test('Administrador acessa o chat somente após o pagamento confirmado',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-admin-chat-'));
 await seedTestData(dir);
 let child;let output='';const port=31386;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 const passageiro=(await fetch(`http://localhost:${port}/api/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'passageiro@caronahub.local',password:'Carona@123'})}));
 const passageiroCookie=passageiro.headers.get('set-cookie')?.split(';')[0];
 const payment=(await fetch(`http://localhost:${port}/api/payment/session`,{method:'POST',headers:{'Content-Type':'application/json',cookie:passageiroCookie},body:JSON.stringify({tripId:'trip1',quantity:1,paymentMethod:'pix'})}));
 assert.equal(payment.status,200);
 const confirm=(await fetch(`http://localhost:${port}/api/payment/confirm`,{method:'POST',headers:{'Content-Type':'application/json',cookie:passageiroCookie},body:JSON.stringify({tripId:'trip1',quantity:1,paymentMethod:'pix'})}));
 assert.equal(confirm.status,200);
 const reserve=(await fetch(`http://localhost:${port}/api/reserve`,{method:'POST',headers:{'Content-Type':'application/json',cookie:passageiroCookie},body:JSON.stringify({tripId:'trip1',quantity:1})}));
 assert.equal(reserve.status,200, 'A reserva precisa existir somente após o pagamento aprovado.');
 const reservationId=(await (await fetch(`http://localhost:${port}/api/state`,{headers:{cookie:passageiroCookie}})).json()).reservations.at(-1).id;
 const admin=(await fetch(`http://localhost:${port}/api/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:'admin@caronahub.local',password:'Carona@123'})}));
 const adminCookie=admin.headers.get('set-cookie')?.split(';')[0];
 const chat=(await fetch(`http://localhost:${port}/api/chat/send`,{method:'POST',headers:{'Content-Type':'application/json',cookie:adminCookie},body:JSON.stringify({reservationId,message:'O ponto de encontro será na praça central.'})}));
 assert.equal(chat.status,200, 'O administrador deve conseguir acessar o chat apenas após o pagamento confirmado.');
 const body=await chat.json();
 assert.ok(body.messages.some((m)=>m.text.includes('praça central')));
 await stop();
});

test('Fluxos completos de autenticação, vagas, permissões e persistência',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-test-'));
 await seedTestData(dir);
 let child;let output='';const port=31387;
 async function start(){child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);for(let i=0;i<100;i++){if(output.includes('Carona Hub:'))return;await new Promise(r=>setTimeout(r,50));if(child.exitCode!==null)throw Error(output);}throw Error('Servidor não iniciou: '+output);}
 async function stop(){if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}}
 t.after(async()=>{await stop();await rm(dir,{recursive:true,force:true});});
 await start();
 async function request(route,body,cookie='',extra={}){const response=await fetch(`http://localhost:${port}/api/${route}`,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',cookie,...extra},body:body===undefined?undefined:JSON.stringify(body)});return {status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]};}
 async function payForTrip(tripId,quantity,cookie){const session=await request('payment/session',{tripId,quantity,paymentMethod:'pix'},cookie);assert.equal(session.status,200,session.data?.error||'Falha ao iniciar pagamento');const confirm=await request('payment/confirm',{tripId,quantity,paymentMethod:'pix'},cookie);assert.equal(confirm.status,200,confirm.data?.error||'Falha ao simular pagamento');}
 const publicState=await request('state');assert.equal(publicState.status,200);assert.equal(publicState.data.trips.length,3);assert.equal(publicState.data.user,null);assert.equal(JSON.stringify(publicState.data).includes('password'),false);
 const html=await fetch(`http://localhost:${port}/`);assert.equal(html.status,200);assert.match(await html.text(),/Carona Hub/);
 for(const asset of ['js/interacoes.js','js/html.js','style.css','favicon.svg','html/buscar.html','html/login.html','html/administracao.html']){const r=await fetch(`http://localhost:${port}/${asset}`);assert.equal(r.status,200,asset);assert.ok((await r.text()).length>100,asset);}
 assert.equal((await request('reserve',{tripId:'trip1',quantity:1})).status,401);
 assert.equal((await request('login',{email:'passageiro@caronahub.local',password:'errada'})).status,401);
 const p=(await request('login',{email:'passageiro@caronahub.local',password:'Carona@123'})).cookie;
 const d=(await request('login',{email:'motorista@caronahub.local',password:'Carona@123'})).cookie;
 const a=(await request('login',{email:'admin@caronahub.local',password:'Carona@123'})).cookie;
 assert.equal((await request('admin/data',{},p)).status,403);
 assert.equal((await request('reserve',{tripId:'trip1',quantity:1},d)).status,403);
 assert.equal((await request('reserve',{tripId:'trip1',quantity:4},p)).status,400);
 assert.equal((await request('reserve',{tripId:'trip1',quantity:1},p,{Origin:'https://invalid.example'})).status,403);
 const reg={name:'Teste Passageiro',cpf:'52998224725',phone:'13988888888',email:'teste@example.com',password:'Teste@123',role:'passageiro'};
 assert.equal((await request('register',reg)).status,200);
 assert.equal((await request('register',reg)).status,400);
 const p2=(await request('login',{email:reg.email,password:reg.password})).cookie;
 await payForTrip('trip1',2,p);await payForTrip('trip1',2,p2);
 const competing=await Promise.all([request('reserve',{tripId:'trip1',quantity:2},p),request('reserve',{tripId:'trip1',quantity:2},p2)]);
 assert.equal(competing.filter(r=>r.status===200).length,1);assert.equal(competing.filter(r=>r.status===400).length,1);
 const winner=competing[0].status===200?p:p2;const loser=winner===p?p2:p;
 let s=(await request('state',undefined,winner)).data;assert.equal(s.trips.find(t=>t.id==='trip1').available,1);const reservation=s.reservations[0];
 assert.equal((await request('reservations/cancel',{id:reservation.id},loser)).status,403);
 assert.equal((await request('reserve',{tripId:'trip1',quantity:1},winner)).status,400);
 assert.equal((await request('reviews',{id:reservation.id,rating:5},winner)).status,400);
 assert.equal((await request('reservations/cancel',{id:reservation.id},winner)).status,200);
 assert.equal((await request('state')).data.trips.find(t=>t.id==='trip1').available,3);
 await payForTrip('trip1',1,p);
 assert.equal((await request('reserve',{tripId:'trip1',quantity:1},p)).status,200);
 const t1=(await request('state')).data.trips[0];
 assert.equal((await request('trips/save',{...t1,capacity:0},d)).status,400);
 assert.equal((await request('trips/save',{...t1,notes:'Novo ponto de encontro'},d)).status,200);
 assert.equal((await request('trips/status',{id:'trip1',status:'concluida'},d)).status,400);
 assert.equal((await request('trips/status',{id:'trip1',status:'cancelada'},d)).status,200);
 s=(await request('state',undefined,p)).data;assert.equal(s.reservations.at(-1).status,'cancelada');assert.ok(s.notifications.length>0);
 assert.equal((await request('admin/event',{name:'Evento teste',category:'Cultura',location:'Santos',date:new Date(Date.now()+86400000*40).toISOString()},a)).status,200);
 let admin=(await request('admin/data',{},a)).data;const event=admin.events.find(e=>e.name==='Evento teste');assert.ok(event);
 assert.equal((await request('admin/event',{id:event.id,remove:true},a)).status,200);
 assert.equal((await request('admin/event',{id:'event1',remove:true},a)).status,400);

 // Aprovação obrigatória, permissões e gerenciamento de todas as viagens.
 const eventBody={name:'Proposta do motorista',category:'Cultura',location:'Santos',date:new Date(Date.now()+86400000*30).toISOString()};
 assert.equal((await request('events/save',eventBody,p)).status,403);
 assert.equal((await request('events/save',{...eventBody,approval:'aprovada'},d)).status,200);
 let driverState=(await request('state',undefined,d)).data;
 const proposedEvent=driverState.myEvents.find(e=>e.name===eventBody.name);
 assert.equal(proposedEvent.approval,'pendente');
 assert.equal((await request('state')).data.events.some(e=>e.id===proposedEvent.id),false);
 assert.equal((await request('admin/moderate',{kind:'event',id:proposedEvent.id,approval:'aprovada'},d)).status,403);
 const newTrip={eventId:proposedEvent.id,origin:'Santos',destination:'Santos',date:new Date(Date.now()+86400000*3).toISOString(),capacity:3,price:35,notes:'Teste de aprovação',approval:'aprovada'};
 assert.equal((await request('trips/save',newTrip,d)).status,400);
 assert.equal((await request('admin/moderate',{kind:'event',id:proposedEvent.id,approval:'rejeitada'},a)).status,400);
 assert.equal((await request('admin/moderate',{kind:'event',id:proposedEvent.id,approval:'aprovada'},a)).status,200);
 assert.equal((await request('state')).data.events.some(e=>e.id===proposedEvent.id),true);
 assert.equal((await request('trips/save',newTrip,d)).status,200);
 driverState=(await request('state',undefined,d)).data;
 const proposedTrip=driverState.myTrips.find(t=>t.eventId===proposedEvent.id);
 assert.equal(proposedTrip.approval,'pendente');
 assert.equal((await request('state')).data.trips.some(t=>t.id===proposedTrip.id),false);
 assert.equal((await request('reserve',{tripId:proposedTrip.id,quantity:1},p)).status,400);
 assert.equal((await request('admin/moderate',{kind:'trip',id:proposedTrip.id,approval:'aprovada'},p)).status,403);
 assert.equal((await request('admin/moderate',{kind:'trip',id:proposedTrip.id,approval:'aprovada'},a)).status,200);
 await payForTrip(proposedTrip.id,1,p);
 assert.equal((await request('reserve',{tripId:proposedTrip.id,quantity:1},p)).status,200);
 assert.equal((await request('trips/save',{...newTrip,id:proposedTrip.id,notes:'Alterada'},d)).status,200);
 assert.equal((await request('state')).data.trips.some(t=>t.id===proposedTrip.id),false);
 assert.equal((await request('admin/moderate',{kind:'trip',id:proposedTrip.id,approval:'rejeitada'},a)).status,400);
 assert.equal((await request('admin/moderate',{kind:'trip',id:proposedTrip.id,approval:'rejeitada',reason:'Preço fora do padrão da plataforma.'},a)).status,200);
 assert.equal((await request('state',undefined,d)).data.myTrips.find(t=>t.id===proposedTrip.id).approval,'rejeitada');
 assert.equal((await request('trips/save',{...newTrip,id:proposedTrip.id},d)).status,200);
 assert.equal((await request('admin/moderate',{kind:'trip',id:proposedTrip.id,approval:'aprovada'},a)).status,200);
 assert.equal((await request('admin/trip/delete',{id:proposedTrip.id},d)).status,403);
 assert.equal((await request('admin/trip/delete',{id:proposedTrip.id},a)).status,200);
 assert.equal((await request('admin/data',{},a)).data.trips.some(t=>t.id===proposedTrip.id),false);
 const deletedReservation=(await request('state',undefined,p)).data.reservations.find(r=>r.tripId===proposedTrip.id);
 assert.equal(deletedReservation.status,'cancelada');assert.equal(deletedReservation.trip.deleted,true);
 assert.equal((await request('trips/save',{...newTrip,id:proposedTrip.id},a)).status,404);
 // Administrador edita e exclui canceladas, concluídas e datas passadas.
 assert.equal((await request('trips/save',{...newTrip,id:'trip1'},a)).status,200);
 assert.equal((await request('admin/trip/delete',{id:'trip1'},a)).status,200);
 assert.equal((await request('trips/save',{...newTrip,eventId:'event2',id:'trip2',date:new Date(Date.now()-86400000).toISOString()},a)).status,200);
 assert.equal((await request('trips/status',{id:'trip2',status:'concluida'},d)).status,200);
 assert.equal((await request('trips/save',{...newTrip,eventId:'event2',id:'trip2',date:new Date(Date.now()-86400000).toISOString(),notes:'Correção histórica'},a)).status,200);
 assert.equal((await request('admin/trip/delete',{id:'trip2'},a)).status,200);
 assert.equal((await request('admin/event',{...eventBody,name:'Novo evento do administrador'},a)).status,200);
 const adminEvent=(await request('admin/data',{},a)).data.events.find(e=>e.name==='Novo evento do administrador');
 assert.equal(adminEvent.approval,'pendente');
 assert.equal((await request('state')).data.events.some(e=>e.id===adminEvent.id),false);
 assert.equal((await request('admin/moderate',{kind:'event',id:adminEvent.id,approval:'rejeitada',reason:'Evento de teste rejeitado.'},a)).status,200);
 assert.equal((await request('profile',{name:'Marina Atualizada',email:'passageiro@caronahub.local',phone:'13999999999'},p)).status,200);
 assert.equal((await request('profile',{name:'Marina Atualizada',email:'passageiro@caronahub.local',phone:'13999999999',password:'Outra@123',currentPassword:'errada'},p)).status,400);
 await stop();await start();assert.equal((await request('state',undefined,p)).data.user.name,'Marina Atualizada');
 assert.equal((await request('recover',{email:'passageiro@caronahub.local'})).status,200);
 const token=output.match(/reset=([a-f0-9]+)/)?.[1];assert.ok(token);
 assert.equal((await request('reset',{token,password:'NovaSenha@123'})).status,200);
 assert.equal((await request('reset',{token,password:'OutraSenha@123'})).status,400);
 assert.equal((await request('state',undefined,p)).data.user,null);
 const newLogin=await request('login',{email:'passageiro@caronahub.local',password:'NovaSenha@123'});assert.equal(newLogin.status,200);
 const pId=(await request('state',undefined,newLogin.cookie)).data.user.id;
 assert.equal((await request('admin/user',{id:pId},a)).status,200);
 assert.equal((await request('state',undefined,newLogin.cookie)).data.user,null);
 assert.equal((await request('login',{email:'passageiro@caronahub.local',password:'NovaSenha@123'})).status,401);
});

test('Conversas: passageiro e motorista conversam, admin vê todas, terceiro não vê',async t=>{
 const dir=await mkdtemp(path.join(tmpdir(),'carona-chats-'));
 await seedTestData(dir);
 let child;let output='';const port=31391;
 child=spawn(process.execPath,['start.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),DATA_DIR:dir,STORAGE:'json',CARONA_NO_DOTENV:'1'},stdio:['ignore','pipe','pipe']});child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);
 for(let i=0;i<100&&!output.includes('Carona Hub:');i++)await new Promise(r=>setTimeout(r,50));
 t.after(async()=>{if(child.exitCode===null){const e=once(child,'exit');child.kill();await e;}await rm(dir,{recursive:true,force:true});});
 async function req(route,body,cookie=''){const r=await fetch(`http://localhost:${port}/api/${route}`,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',cookie},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
 const login=async(email,password='Carona@123')=>(await req('login',{email,password})).cookie;
 const p=await login('passageiro@caronahub.local'),d=await login('motorista@caronahub.local'),a=await login('admin@caronahub.local');
 await req('register',{name:'Outro Passageiro',cpf:'52998224725',phone:'13988888888',email:'outro@example.com',password:'Teste@123',role:'passageiro'});
 const x=await login('outro@example.com','Teste@123');
 assert.equal((await req('chats')).status,401);
 await req('payment/session',{tripId:'trip1',quantity:1,paymentMethod:'pix'},p);await req('payment/confirm',{tripId:'trip1',quantity:1,paymentMethod:'pix'},p);
 assert.equal((await req('reserve',{tripId:'trip1',quantity:1},p)).status,200);
 const rid=(await req('chats',undefined,p)).data.chats[0].reservationId;
 assert.equal((await req('chat/send',{reservationId:rid,message:'Oi, onde te encontro?'},p)).status,200);
 const drv=(await req('chats',undefined,d)).data.chats;
 assert.equal(drv.length,1);assert.equal(drv[0].messages.at(-1).text,'Oi, onde te encontro?');
 assert.equal((await req('chat/send',{reservationId:rid,message:'Na praça às 18h.'},d)).status,200);
 const adm=(await req('chats',undefined,a)).data.chats;
 assert.equal(adm[0].messages.length,3);
 assert.equal((await req('chats',undefined,x)).data.chats.length,0);
 assert.equal((await req('chat/send',{reservationId:rid,message:'intruso'},x)).status,403);
});
