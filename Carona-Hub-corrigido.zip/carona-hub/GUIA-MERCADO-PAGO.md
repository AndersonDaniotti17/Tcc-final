# Guia de integração: Mercado Pago com split (15% plataforma / 85% motorista)

> **Importante:** mantenha esta integração em ambiente de testes para a apresentação acadêmica. Como pagamentos reais envolvem uma conta financeira e movimentação de dinheiro, qualquer criação/configuração de conta de produção e uso de credenciais reais deve ficar sob responsabilidade de um adulto responsável. Nunca envie o arquivo `.env`, tokens ou chaves por mensagem ou repositório.

## 1. Como funciona

Modelo **marketplace (Split de pagamentos 1:1)** com **Checkout Pro**:

1. Cada **motorista conecta a própria conta Mercado Pago** uma vez (botão em *Minhas viagens*, via OAuth).
2. O passageiro clica em **Pagar e reservar** e paga na página segura do Mercado Pago (cartão, Pix ou saldo).
3. O pagamento cai na **conta do motorista** e o Mercado Pago repassa **15% (`marketplace_fee`) para a conta da plataforma** automaticamente.
4. A reserva só é criada quando o Mercado Pago avisa, por **webhook assinado**, que o pagamento foi aprovado.

Exemplo para uma reserva de R$ 51,00: comissão da plataforma R$ 7,65; o restante é do motorista. **A tarifa do próprio Mercado Pago é descontada do valor do motorista primeiro, e só depois a comissão da plataforma** (conforme a documentação do split).

Viagens de motoristas que ainda não conectaram o Mercado Pago **não aparecem** para os passageiros.

## 2. O que mudou no projeto

| Arquivo | O que faz |
|---|---|
| `server.js` | Conexão OAuth do motorista, criação do pagamento com comissão, webhook, reembolso, renovação dos tokens |
| `pagamentos.js` (novo) | Assinatura do webhook, conciliação do pagamento, cálculo da comissão, criptografia dos tokens |
| `store.js`, `database/schema.sql` | Tabela `tb_pagamento` e colunas do Mercado Pago nos usuários (JSON e MySQL) |
| `public/js/interacoes.js`, `public/html/viagens.html` | Botão "Conectar Mercado Pago", redirecionamento ao pagar e retorno ao site |
| `tests/pagamentos.test.js` (novo) | 10 testes (assinatura, conciliação, comissão, criptografia) |

Sem as variáveis do Mercado Pago no `.env`, o site continua em **modo demonstração**. Nesse modo, Pix e cartão são apenas simulações acadêmicas: nenhum pagamento real é processado. Com credenciais de teste válidas, o sistema redireciona para o checkout de testes do Mercado Pago.

## 3. Passo a passo

### 3.1 Instalar
```
npm install
```

### 3.2 Criar a aplicação marketplace
1. **Mercado Pago Developers > Suas integrações > Criar aplicação**.
2. Solução **Pagamentos online**, produto **Checkout Pro**, modelo de integração **Marketplace**. O Mercado Pago pode pedir verificação de identidade.
3. Na edição da aplicação, preencha a **Redirect URL** com exatamente:
   `https://SEU-ENDERECO/api/mp/callback`
4. Copie o **App ID** (client_id) e a **Secret Key** (client_secret).
5. Em **Webhooks**, configure `https://SEU-ENDERECO/api/payment/webhook`, evento **Pagamentos**, e copie a **Assinatura secreta**.

### 3.3 Endereço https para testes locais
Use um túnel (`cloudflared tunnel --url http://localhost:3000` ou `ngrok http 3000`). O Mercado Pago só avisa o webhook e só redireciona de volta em endereço público https.

### 3.4 Preencher o `.env`
```
APP_URL=https://SEU-ENDERECO
MERCADO_PAGO_CLIENT_ID=<App ID>
MERCADO_PAGO_CLIENT_SECRET=<Secret Key>
MERCADO_PAGO_WEBHOOK_SECRET=<assinatura secreta>
PLATFORM_FEE_PERCENT=15
TOKEN_ENCRYPTION_KEY=<64 caracteres hexadecimais>
```
Gere a chave de criptografia com:
```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
**Guarde uma cópia segura dessa chave.** Ela criptografa os tokens dos motoristas no banco; se for perdida, todos precisam reconectar. O servidor não inicia sem ela.

Nunca envie o `.env` por zip, chat ou GitHub.

### 3.5 Testar (sandbox)
1. Rode `node start.js` e abra o endereço do túnel.
2. Entre como **motorista** > *Minhas viagens* > **Conectar Mercado Pago**. Autorize com uma **conta de teste de vendedor**.
3. Crie uma viagem e aprove como admin.
4. Entre como **passageiro** e pague com uma **conta de teste de comprador** e os cartões de teste da documentação.
5. Confirme: a reserva aparece como confirmada, o motorista recebe o valor menos a comissão e a plataforma recebe os 15%.
6. Teste também pagamento recusado e cancelamento de reserva paga (reembolso).

## 4. Segurança
- Valor e comissão são calculados **no servidor**; o navegador não define preço.
- O webhook exige assinatura válida (401 sem ela) e o pagamento é **consultado na API** com o token do motorista, nunca confiado do corpo do aviso. Valor, moeda e referência são conferidos; avisos repetidos não duplicam a reserva.
- A rota de reserva direta fica **bloqueada** com o Mercado Pago ativo: sem pagar, não reserva.
- Tokens dos motoristas ficam **criptografados (AES-256-GCM)** no armazenamento e **nunca** são enviados ao navegador.
- O `state` do OAuth é aleatório, expira em 10 minutos e vale uma única vez.
- Os tokens dos motoristas valem 6 meses; o servidor renova automaticamente a cada 12 horas os que vencem em 30 dias. Se a renovação falhar e o token expirar, o motorista precisa reconectar (a viagem some da busca até lá).

## 5. Pagamentos habilitados e pontos que precisam ser validados no sandbox
Estes pontos dependem do comportamento real do Mercado Pago, que eu não consegui testar daqui (sem acesso à rede). O código falha de forma segura em todos eles, mas confirme:

1. **Pix e cartão no split:** a documentação do split 1:1 menciona pagamento com saldo entre contas Mercado Pago e restrições a transferências externas. Confirme separadamente um Pix e um cartão de crédito de teste no fluxo marketplace e na conta de vendedor autorizada. O código permite selecionar os dois métodos, mas a disponibilidade final depende das regras e da habilitação da conta no Mercado Pago.
2. **Assinatura do webhook:** confirme que os avisos das contas de motoristas chegam com `x-signature` válida usando a assinatura secreta da sua aplicação. Se chegarem 401, veja o log do servidor.
3. **Reembolso:** o reembolso é pedido com o token do motorista. Na documentação, o reembolso é dividido proporcionalmente entre motorista e plataforma, e o marketplace **não consegue reembolso total se o motorista não tiver saldo**. Se falhar, o cancelamento é abortado (nada muda); numa viagem que lotou durante o pagamento, o admin recebe um aviso para devolver pelo painel.
4. **Renovação de token:** usa o mesmo endpoint `/oauth/token` com `grant_type=refresh_token`; confira na documentação "Renovação" do Mercado Pago.

## 6. Produção (somente após validação e autorização do responsável pela conta)
1. Credenciais de produção da aplicação, domínio com **https** e a Redirect URL/webhook atualizados no painel. Para este projeto acadêmico, mantenha os testes no sandbox; qualquer ativação financeira real deve ser feita pelo responsável adulto pela conta e após revisão dos termos, taxas e obrigações aplicáveis.
2. Cada motorista conecta a conta Mercado Pago **real** dele.
3. Faça um pagamento real de valor baixo e um reembolso para validar o fluxo completo.
4. Se algum token ou o `.env` já foi compartilhado, gere novos.

## 7. Decisões suas
- **Reembolso:** hoje, cancelar antes da saída devolve 100%. Taxa ou prazo se ajustam na rota `reservations/cancel`.
- **Desconectar conta:** ainda não há botão para o motorista desconectar; ele pode revogar a autorização no Mercado Pago.
- **Termos:** informe aos motoristas a comissão de 15% e que a tarifa do Mercado Pago sai da parte deles.

## 8. Observação sobre a API usada

O projeto existente usa o Checkout Pro clássico, baseado na API de Preferências, para evitar uma reescrita ampla do fluxo de pagamentos. A documentação atual do Mercado Pago também apresenta a API de Orders como caminho recomendado para novas integrações; a migração pode ser planejada separadamente, depois que o fluxo atual estiver validado no sandbox.
