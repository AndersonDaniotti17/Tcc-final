# O que mudou nesta versão

## 1. Chat motorista ↔ passageiro (admin vê tudo)
- Novo item no menu **Conversas** para passageiro, motorista e admin.
- Passageiro vê as conversas das reservas dele; motorista vê as das viagens dele; **admin vê todas** ("Conversas (todas)") e pode escrever como Administração.
- O chat abre quando a reserva é paga/confirmada. A 1ª mensagem é o ponto de encontro do motorista. Reserva cancelada vira somente leitura.
- Cada mensagem gera aviso para o outro lado.
- Mensagens agora ficam em tabela própria `tb_mensagem` (antes ficavam dentro da reserva e **não eram salvas no MySQL**). Conversas antigas do modo JSON são migradas sozinhas.
- Rotas: `GET /api/chats` e `POST /api/chat/send`. Teste novo em `tests/app.test.js`.

## 2. Pagamento (Mercado Pago)
O erro mais comum: rodando em `http://localhost`, o Mercado Pago **não consegue chamar o webhook**, então o pagamento era aprovado mas a reserva nunca era criada.
Agora, ao voltar do checkout, o site pega o `payment_id` da URL e o servidor consulta o pagamento direto na API do Mercado Pago (`POST /api/payment/check`) e confirma a reserva.

### Jeito mais simples de testar (sem split, sem túnel)
1. Mercado Pago Developers → Suas integrações → Criar aplicação (Checkout Pro).
2. Em **Credenciais de teste**, copie o *Access Token* (começa com `TEST-` ou `APP_USR` de usuário de teste).
3. Crie `.env` (copie de `.env.example`) só com:
   ```
   MERCADO_PAGO_ACCESS_TOKEN=TEST-xxxxxxxx
   APP_URL=http://localhost:3000
   ```
4. `npm install` e `node start.js`.
5. Pague com um **cartão de teste** do Mercado Pago (titular `APRO`) logado com um **comprador de teste** (não use sua conta real, o MP recusa pagar a si mesmo).
6. Depois de aprovar, clique em **Voltar ao site** — a reserva entra e o chat abre.

O split 15%/85% (marketplace com CLIENT_ID/SECRET) continua igual ao `GUIA-MERCADO-PAGO.md` e precisa de endereço https (ngrok/cloudflared).
